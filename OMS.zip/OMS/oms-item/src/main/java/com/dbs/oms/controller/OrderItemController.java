package com.dbs.oms.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.dbs.oms.entity.OrderItem;
import com.dbs.oms.exception.OrderNotFoundException;
import com.dbs.oms.service.OrderItemService;

@RestController
@RestControllerAdvice
@Validated
@RequestMapping("/api/orderitem")
public class OrderItemController {

	private static final Logger log = LoggerFactory.getLogger(OrderItemController.class);

	@Autowired
	OrderItemService orderItemService;

	@GetMapping("/getalloderitem")
	public List<OrderItem> getAllOrderItem() {
		return orderItemService.getAllOrderItem();
	}

	@GetMapping("/getoderitem/{id}")
	public OrderItem getOrderItemById(@PathVariable("id") Integer id) throws OrderNotFoundException {
		OrderItem orderItem = orderItemService.getOrderItemById(id);
		log.info("order:" + orderItem);

		return orderItem;
	}

	@PostMapping("/createorderitem")
	public OrderItem createOrderItem(@Valid @RequestBody OrderItem orderItem) throws OrderNotFoundException {
		return orderItemService.createOrderItem(orderItem);
	}

}
