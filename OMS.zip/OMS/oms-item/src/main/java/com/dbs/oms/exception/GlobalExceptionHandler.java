package com.dbs.oms.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dbs.oms.response.ExceptionResponse;

/**
 * @author bhadra
 *
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(OrderNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ResponseEntity<ExceptionResponse> OrderNotFoundException(OrderNotFoundException onException,
			WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(onException.getMessage(), HttpStatus.NOT_FOUND,
				new String());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ExceptionResponse handelException(final Exception exception,
			final HttpServletRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(exception.getMessage(), HttpStatus.NOT_FOUND,
				request.getRequestURI());
		exceptionResponse.setErrorMessage(exceptionResponse.getErrorMessage());
		exceptionResponse.setErrorCode(exceptionResponse.getErrorCode());
		exceptionResponse.setRequestedURI(exceptionResponse.getRequestedURI());
		return exceptionResponse;
	}

}
