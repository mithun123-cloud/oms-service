package com.dbs.oms.service;

import java.util.List;

import com.dbs.oms.entity.OrderItem;


public interface OrderItemService {

	public List<OrderItem> getAllOrderItem();
	public OrderItem createOrderItem(OrderItem orderItem);
	public OrderItem getOrderItemById(Integer id);
}
