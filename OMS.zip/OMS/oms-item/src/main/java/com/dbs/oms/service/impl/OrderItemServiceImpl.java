package com.dbs.oms.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.oms.entity.OrderItem;
import com.dbs.oms.exception.OrderNotFoundException;
import com.dbs.oms.repo.OrderItemRepository;
import com.dbs.oms.service.OrderItemService;

@Service
public class OrderItemServiceImpl implements OrderItemService {

	private static final Logger log = LoggerFactory.getLogger(OrderItemServiceImpl.class);

	@Autowired
	OrderItemRepository orderItemRepository;

	@Override
	public List<OrderItem> getAllOrderItem() {
		log.debug("inside getAllOrderItem");
		return orderItemRepository.findAll();
	}

	public OrderItem createOrderItem(OrderItem orderItem) throws OrderNotFoundException {
		log.debug("inside createOrUpdateOrderItem");
		return orderItemRepository.save(orderItem);
	}

	public OrderItem getOrderItemById(Integer id) throws OrderNotFoundException {
		log.debug("inside getOrderItemById for id " + id);
		return orderItemRepository.findById(id).get();
	}

}