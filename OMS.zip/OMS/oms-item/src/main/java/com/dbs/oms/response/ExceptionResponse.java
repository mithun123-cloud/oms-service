package com.dbs.oms.response;

import org.springframework.http.HttpStatus;

/**
 * @author bhadra
 *
 */
public class ExceptionResponse {

	private String errorMessage;
	private HttpStatus errorCode;
	private String requestedURI;

	public ExceptionResponse(String errorMessage, HttpStatus errorCode, String requestedURI) {
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		this.requestedURI = requestedURI;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public HttpStatus getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(HttpStatus errorCode) {
		this.errorCode = errorCode;
	}

	public String getRequestedURI() {
		return requestedURI;
	}

	public void setRequestedURI(String requestedURI) {
		this.requestedURI = requestedURI;
	}
}
