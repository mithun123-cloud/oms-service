package com.dbs.oms.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.oms.entity.OrderItem;
import com.dbs.oms.repo.OrderItemRepository;
/**
 * @author bhadra
 */

@RunWith(SpringRunner.class)
//@ContextConfiguration
@SpringBootTest
public class OrderItemServiceTest {

	//@Autowired
	@MockBean
	OrderItemService orderItemService;
	@MockBean
	OrderItemRepository orderItemRepository;
	
	@Test
	public void getOrderItemTest(){
		when(orderItemRepository.findAll()).thenReturn(Stream.of(new OrderItem()).collect(Collectors.toList()));
		assertEquals(1, orderItemService.getAllOrderItem().size());
		verify(orderItemService.getAllOrderItem());
	}
}
