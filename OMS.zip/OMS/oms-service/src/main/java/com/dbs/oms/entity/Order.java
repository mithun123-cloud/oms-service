package com.dbs.oms.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;
/**
 * @author bhadra
 * @version 1.0
 */

@Entity
@Table(name="ORDERS")
public class Order implements Serializable{

	
	private static final long serialVersionUID = 9012815534386126862L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ORDER_ID")
	private int orderId;
	
	@Column(name="CUSTOMER_NAME")
	private String customerName;
	
	@Column(name="ORDER_DATE")
	private Date orderDate;
	
	@Column(name="SHIPPING_ADDRESS")
	private String shippingAddress;
	
	@Column(name="TOTAL_PRICE")
	private double total;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "order")
	@JsonManagedReference
	private List<OrderServiceItem> orderServiceItem;
	
	private int orderItemId;
	
	public Order() {
	}
	
	public Order(int orderId, String customerName, Date orderDate, String shippingAddress, double total) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.total = total;
	}




	public int getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}

	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}


	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public List<OrderServiceItem> getOrderServiceItem() {
		return orderServiceItem;
	}

	public void setOrderServiceItem(List<OrderServiceItem> orderServiceItem) {
		this.orderServiceItem = orderServiceItem;
	}

}

