package com.dbs.oms.service;

import java.util.List;

import com.dbs.oms.entity.Order;
import com.dbs.oms.entity.Status;

public interface OrderService {
	
	Status createOrder(Order order);
	List<Order> getOrders();
}
