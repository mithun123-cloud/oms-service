package com.dbs.oms.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.dbs.oms.entity.OrderItemsDto;
import com.dbs.oms.response.Response;

//@FeignClient(name = "orderItemService", url = "localhost:8088")
@FeignClient(name = "orderItemService")
public interface OrderServiceFeignClient {
	@GetMapping(path="/api/orderitem/getalloderitem")
	public Response<List<OrderItemsDto>> getAllOrderItem();

}
