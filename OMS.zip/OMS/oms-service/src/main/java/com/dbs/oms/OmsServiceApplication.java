package com.dbs.oms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.dbs.oms.feignclient")
public class OmsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmsServiceApplication.class, args);
	}

}
