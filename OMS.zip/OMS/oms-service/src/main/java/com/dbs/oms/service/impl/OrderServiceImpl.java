package com.dbs.oms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.dbs.oms.entity.Order;
import com.dbs.oms.entity.OrderItemsDto;
import com.dbs.oms.entity.OrderServiceItem;
import com.dbs.oms.entity.Status;
import com.dbs.oms.exception.OrderNotFoundException;
import com.dbs.oms.feignclient.OrderServiceFeignClient;
import com.dbs.oms.repository.OrderRepository;
import com.dbs.oms.response.Response;
import com.dbs.oms.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OrderRepository orderRepository;

	@Autowired(required = true)
	private OrderServiceFeignClient orderServiceFeignClient;

	@Override
	@Transactional
	public Status createOrder(Order order) {
		
		Status statusVo = new Status();
		Response<List<OrderItemsDto>> items = orderServiceFeignClient.getAllOrderItem();
		List<OrderItemsDto> orderItemsDto = new ArrayList<OrderItemsDto>();
		log.info("item from oder item service : "+items);
		for (OrderItemsDto orderItem : items.getData())
			orderItemsDto.add(orderItem);
		log.info("item from oder item service orderItemsDto : "+orderItemsDto);

		if (Objects.nonNull(order)) {
			Order orderDetails = new Order();
			orderDetails.setCustomerName(order.getCustomerName());
			orderDetails.setOrderDate(order.getOrderDate());
			orderDetails.setShippingAddress(order.getShippingAddress());
			orderDetails.setTotal(order.getTotal());
			orderDetails = orderRepository.save(orderDetails);
			statusVo.setKey(orderDetails.getOrderId());
			statusVo.setStatus("SUCCESS");

			OrderServiceItem orderServiceItem = new OrderServiceItem();
			orderServiceItem.setOrderItemId(items.getData().iterator().next().getOrderItemId());
			orderServiceItem.setOrderId(orderDetails.getOrderId());
		} else {
			// throw new
			// BaseException(ExceptionConstants.ORDER_SAVE,ExceptionConstants.ORDER_SERVICE_MANAGMENT);
			throw new OrderNotFoundException();
		}
		return statusVo;
	}

	@Override
	public List<Order> getOrders() {
		List<Order> orders = new ArrayList<Order>();
		orders = orderRepository.getOrders();
		if (Objects.nonNull(orders)) {
			return orders;

		} else {
			// throw new
			// BaseException(ExceptionConstants.ORDERS_NOT_FOUND,ExceptionConstants.ORDER_SERVICE_MANAGMENT);
			throw new OrderNotFoundException();
		}
	}
}
