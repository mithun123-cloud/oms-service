package com.dbs.oms.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(value = Include.NON_NULL)
@JsonPropertyOrder({ "success", "data", "result" })
public class Response<R> extends GenericResponse {

	private static final long serialVersionUID = -4171432404221674068L;
	private R data;

	public R getData() {
		return data;
	}

	public void setData(R data) {
		this.data = data;
	}

}
