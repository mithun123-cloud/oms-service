package com.dbs.oms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.oms.entity.Order;
import com.dbs.oms.entity.Status;
import com.dbs.oms.response.Response;
import com.dbs.oms.service.OrderService;

/**
 * @author bhadra
 * @version 1.0
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OrderService orderService;

	@PostMapping("/createorder")
	public Response<Status> createOrder(@RequestBody Order order) {
		Response<Status> response = new Response<Status>();
		response.setResponseOK();
		response.setData(orderService.createOrder(order));
		log.info("response:" + response);
		return response;
	}

	@GetMapping("/getorderslist")
	public Response<List<Order>> OrderedItems() {
		Response<List<Order>> response = new Response<List<Order>>();
		response.setResponseOK();
		response.setData(orderService.getOrders());
		log.info("response:" + response);
		return response;
	}
}
