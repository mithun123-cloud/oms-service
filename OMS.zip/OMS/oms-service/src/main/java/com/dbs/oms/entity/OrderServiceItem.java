package com.dbs.oms.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * @author bhadra
 *
 */
@Entity
@Table(name="ORDER_SEVICE_ITEM")
public class OrderServiceItem  implements Serializable{

	
	private static final long serialVersionUID = -7060939342203286517L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ORDER_SERVICE_ITEM_ID")
	private int orderServiceItemId;
	
	@Column(name="ORDER_ITEM_ID")
	private int orderItemId;
	
	@Column(name="ORDER_ID")
	private int orderId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID",insertable = false, updatable = false)
	@JsonBackReference
	private Order order;
	

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public int getOrderServiceItemId() {
		return orderServiceItemId;
	}

	public void setOrderServiceItemId(int orderServiceItemId) {
		this.orderServiceItemId = orderServiceItemId;
	}

	public int getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
}
